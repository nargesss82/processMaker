$(document).ready(function () {
  // Define all sections with their configuration
  const sections = [
    {
      id: "subtitle0000000001",
      fields: [
        "#txt_fullname",
        "#txt_nationalCode",
        "#dat_birthday",
        "#txt_fathername",
        "#txt_certificateNumber",
        "#txt_phone",
        "#txt_telephone",
        "#rad_gender",
        "#txt_birthPlace"
      ],
      style: {
        backgroundColor: "#ddfccc",
        color: "#01574a"
      }
    },
    {
      id: "subtitle0000000002",
      fields: [
        "#txt_legalTelephone",
        "#txt_legalPhone",
        "#txt_legalNationalCode",
        "#txt_legalFullname"
      ],
      style: {
        backgroundColor: "#ddfccc",
        color: "#01574a"
      }
    },
    {
      id: "subtitle0000000003",
      fields: [
        "#txt_postalCode",
        "#drp_province",
        "#drp_city",
        "#txr_address",
        "#txt_domainTelephone"
      ],
      style: {
        backgroundColor: "#ddfccc",
        color: "#01574a"
      }
    },
    {
      id: "subtitle0000000004",
      fields: [
        "#mfi_uploadFile",
        "#txt_file"
      ],
      style: {
        backgroundColor: "#014339",
        color: "white"
      }
    }
  ];

  // Initialize all sections
  sections.forEach(section => {
    // Store visibility state in the section object
    section.visible = false;
    
    // Apply initial styles
    const $header = $(`#${section.id}`);
    $header.css({
      cursor: "pointer",
      backgroundColor: section.style.backgroundColor,
      padding: "10px",
      borderRadius: "6px",
      marginBottom: "10px",
      color: section.style.color
    });
    
    // Hide fields initially
    $(section.fields.join(", ")).hide();
    
    // Add click handler
    $header.click(function() {
      section.visible = !section.visible;
      
      if (section.visible) {
        $(section.fields.join(", ")).slideDown(300);
        $(`#${section.id} .icon`).html("▼");
      } else {
        $(section.fields.join(", ")).slideUp(300);
        $(`#${section.id} .icon`).html("►");
      }
    });
    
    // Add icon if it doesn't exist
    if ($(`#${section.id} .icon`).length === 0) {
      $header.append('<span class="icon">►</span>');
    }
  });  
});

///////////////////////////////////////////////////////////////////////////
/*function sendAjaxRequest() {
  var nationalID = $("#txt_nationalCode").find("input").val().trim();
  var postalCode = $("#txt_postalCode").find("input").val().trim();
  console.log(nationalID);
  var dataInfo = {
    national_id: nationalID,
    postal_code: postalCode
  };

  $.ajax({
    url: window.location,
    type: "POST",
    data: {
      act: "checkUserExists",
      dataInfo:dataInfo
    },
    async: false,
    dataType: "json",
    success: function () {
      console.log('success of allAjaxFun:');
    },
    error: function (xhr, status, error) {
      console.error("Error loading data: " + error);
      console.log("Response:", xhr.responseText);
    }
  });
}*/
function sendAjaxRequest() {
  var nationalID = $("#txt_nationalCode").getValue();
  var postalCode = $("#txt_postalCode").getValue();
  console.log("National ID:", nationalID, "Postal Code:", postalCode); // For debugging
  
  var dataInfo = {
    national_id: nationalID,
    postal_code: postalCode
  };

  $.ajax({
    url: window.location.href, // Make sure this URL correctly points to your PHP script
    type: "POST",
    data: {
      act: "checkUserExists",
      dataInfo: JSON.stringify(dataInfo) // Crucial: stringify the object
    },
    dataType: "json", // Expect JSON response
    success: function(response) {
      console.log('AJAX Success:', response);
      // Handle your response here
      if(response && response.result) {
        alert("Success: " + response.result.status);
      } else if (response && response.error) {
        alert("Application Error: " + response.error);
      }
    },
    error: function(xhr, status, error) {
      console.error("AJAX Error Status:", status);
      console.error("AJAX Error Message:", error);
      console.log("Full AJAX Response Text:", xhr.responseText); // THIS IS VERY IMPORTANT
      alert("Failed to process request. Check console for details. Response: " + xhr.responseText.substring(0, 200));
    }
  });
}

 // بررسی ساختار کلی (طول و فقط عدد بودن)
    function validateField(selector, length, label) {
     // const $input = $("#"+selector).find("input");
      const value = $(`#${selector}`).getValue();
      console.log("validateField:",value);
      if (!/^\d+$/.test(value) || value.length !== length) {
       // $(`#${selector}`).style.setProperty("border", "2px solid red", "important");
        errorMessages.push();
            alert(`${label} باید ${length} رقم و فقط عدد باشد.`);

        return false;
      } else {
        //$(`#${selector}`).style.setProperty("border", "1px solid #ccc", "important");
        return true;
      }
    }

     // بررسی الگوریتم کد ملی
    function isValidIranianNationalCode(input) {
      if (!/^\d{10}$/.test(input)) return false;
      if (/^(\d)\1{9}$/.test(input)) return false;

      const check = parseInt(input[9]);
      const sum = input
        .split('')
        .slice(0, 9)
        .reduce((total, num, i) => total + parseInt(num) * (10 - i), 0);
      const remainder = sum % 11;

      return (remainder < 2 && check === remainder) || (remainder >= 2 && check === 11 - remainder);
    }
let errorMessages = [];
$(document).ready(function () {
  $("#sbt_submit").click(function (e) {
    e.preventDefault(); // جلوگیری از ارسال فرم

    let isValid = true;
    

     
if(!validateField("txt_telephone", 11, "تلفن ثابت") ||
!validateField("txt_phone", 11, "تلفن همراه")||
!validateField("txt_postalCode", 11, "کد پستی")
){
return;
}
   

    // اعتبارسنجی فیلدها
    if (!validateField("txt_telephone", 11, "تلفن ثابت")) isValid = false;
    if (!validateField("txt_phone", 11, "تلفن همراه")) isValid = false;
    if (!validateField("txt_postalCode", 10, "کدپستی")) isValid = false;
    if (!validateField("txt_nationalCode", 10, "کدملی")) isValid = false;

    // بررسی معتبر بودن کد ملی
    if (isValid) {
      const nationalCode = $("#txt_nationalCode").find("input").val().trim();
      if (!isValidIranianNationalCode(nationalCode)) {
        $("#txt_nationalCode").find("input")[0].style.setProperty("border", "2px solid red", "important");
        errorMessages.push("کد ملی نامعتبر است.");
        isValid = false;
      }
    }

     
 
    
    
    // نمایش خطاها یا ارسال فرم
    if (!isValid) {
      alert(errorMessages.join("\n"));
    } else {
       sendAjaxRequest();
      
    }
  });
});


/////////////////////////////////////////////////////////////////////
function showS() {
  const value = $("#drp_status").getControl().val();
  if (value != "0") {
    $("#subtitle0000000002").show();
    $("#subtitle0000000001").hide();
  } else {
    $("#subtitle0000000002").hide();
    $("#subtitle0000000001").show();
  }
}

// اجرای اولیه بعد از اینکه DOM کاملاً لود شد
$(document).ready(function () {
  showS(); // اجرای تابع در ابتدا
  $("#drp_status").change(showS); // اضافه کردن event listener
});
//////////////////////////////////
/*$(document).ready(function () {
$("#sbt_submit").click(function(e){
var nationalID = $("#txt_nationalCode").val();
var postalCode = $("#txt_postalCode").val();
console.log(nationalID);
console.log(postalCode);
//alert(nationalID);
var dataInfo = {
  national_id: nationalID,
  postal_code: postalCode
};

$.ajax({
    url: window.location,
    type: "POST",
    data: {
      act: "checkUserExists",
      dataInfo: JSON.stringify(dataInfo) // به صورت آرایه‌ای (json) فرستاده شود
    },
    //async: false,
    dataType: "json",
    success: function (data) {
      console.log('success of allAjaxFun:', data);
    },
    error: function (xhr, status, error) {
      console.error("Error loading data: " + error);
    }
});
});
});*/